"""
Random Features from Untrained CNN for MNIST Classification
This script demonstrates that an untrained CNN can extract meaningful features
that enable high classification accuracy when combined with a linear SVM.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from torchvision import datasets, transforms
from sklearn.svm import LinearSVC
from sklearn.metrics import accuracy_score
import numpy as np
import random

# Set random seeds for reproducibility
RANDOM_SEED = 42
torch.manual_seed(RANDOM_SEED)
np.random.seed(RANDOM_SEED)
random.seed(RANDOM_SEED)
if torch.cuda.is_available():
    torch.cuda.manual_seed(RANDOM_SEED)


# Define the CNN architecture
class SimpleCNN(nn.Module):
    def __init__(self):
        super(SimpleCNN, self).__init__()
        # First convolutional block
        self.conv1 = nn.Conv2d(1, 16, kernel_size=3, padding=1)
        self.pool1 = nn.MaxPool2d(2, 2)

        # Second convolutional block
        self.conv2 = nn.Conv2d(16, 32, kernel_size=3, padding=1)
        self.pool2 = nn.MaxPool2d(2, 2)

        # Fully connected layer (feature layer)
        # After two 2x2 maxpool: 28x28 -> 14x14 -> 7x7
        self.fc = nn.Linear(32 * 7 * 7, 128)

    def forward(self, x):
        # First conv block
        x = self.conv1(x)
        x = F.relu(x)
        x = self.pool1(x)

        # Second conv block
        x = self.conv2(x)
        x = F.relu(x)
        x = self.pool2(x)

        # Flatten and pass through FC layer
        x = x.view(x.size(0), -1)
        x = self.fc(x)

        return x


def extract_features(model, data_loader, device):
    """Extract features from the untrained CNN"""
    model.eval()
    features_list = []
    labels_list = []

    with torch.no_grad():
        for data, labels in data_loader:
            data = data.to(device)
            features = model(data)
            features_list.append(features.cpu().numpy())
            labels_list.append(labels.numpy())

    return np.vstack(features_list), np.concatenate(labels_list)


def main():
    # Device configuration
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"Using device: {device}")

    # Load MNIST dataset
    transform = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize((0.1307,), (0.3081,))
    ])

    train_dataset = datasets.MNIST(root='./data', train=True,
                                   download=True, transform=transform)
    test_dataset = datasets.MNIST(root='./data', train=False,
                                  download=True, transform=transform)

    train_loader = torch.utils.data.DataLoader(train_dataset,
                                               batch_size=512,
                                               shuffle=False)
    test_loader = torch.utils.data.DataLoader(test_dataset,
                                              batch_size=512,
                                              shuffle=False)

    # Initialize the untrained CNN
    model = SimpleCNN().to(device)
    print("\nCNN Architecture:")
    print(model)
    print("\nNetwork initialized with random weights (NO TRAINING)")

    # Extract random features from training set
    print("\nExtracting features from training set...")
    train_features, train_labels = extract_features(model, train_loader, device)
    print(f"Training features shape: {train_features.shape}")

    # Extract random features from test set
    print("Extracting features from test set...")
    test_features, test_labels = extract_features(model, test_loader, device)
    print(f"Test features shape: {test_features.shape}")

    # Train Linear SVM on the random features
    print("\nTraining Linear SVM on random features...")
    svm = LinearSVC(random_state=RANDOM_SEED, max_iter=2000, dual=False)
    svm.fit(train_features, train_labels)

    # Evaluate on test set
    test_predictions = svm.predict(test_features)
    test_accuracy = accuracy_score(test_labels, test_predictions)

    print(f"\n{'=' * 50}")
    print(f"FINAL TEST ACCURACY: {test_accuracy * 100:.2f}%")
    print(f"{'=' * 50}")

    # Additional analysis
    train_predictions = svm.predict(train_features)
    train_accuracy = accuracy_score(train_labels, train_predictions)
    print(f"\nTraining accuracy: {train_accuracy * 100:.2f}%")
    print(f"Number of training samples: {len(train_labels)}")
    print(f"Number of test samples: {len(test_labels)}")


if __name__ == "__main__":
    main()
