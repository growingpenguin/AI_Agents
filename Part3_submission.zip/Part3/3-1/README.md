# Random Features from Untrained CNN - MNIST Classification

## Overview
This project demonstrates that an untrained CNN can extract meaningful features for MNIST digit classification when combined with a linear SVM classifier.

## Installation

1. Create a virtual environment (recommended):
```bash
python3 -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

2. Install dependencies:
```bash
pip install -r requirements.txt
```

## Running the Code

```bash
python random_features_cnn.py
```

## Results

Using random seeds fixed at 42 for reproducibility:

| Metric | Value |
|--------|-------|
| **Test Accuracy** | **94.37%** |
| Training Accuracy | 94.21% |
| Training Samples | 60,000 |
| Test Samples | 10,000 |
| Feature Dimension | 128 |

---

## Deliverable (c): Answers to Questions

### i. What do you observe about the results?

The results are surprisingly impressive:

1. **High Accuracy Without Training**: The untrained CNN achieves **94.37% test accuracy** on MNIST, which is remarkably close to what a trained CNN might achieve (~99%). This means that random weights already encode useful transformations.

2. **No Overfitting**: The training accuracy (94.21%) and test accuracy (94.37%) are nearly identical, indicating excellent generalization. This is expected because the CNN weights are not fitted to the training data at all.

3. **Simple Linear Classifier Suffices**: A basic linear SVM can achieve this accuracy, meaning the random CNN features are approximately linearly separable. The nonlinear transformations from the CNN architecture (convolutions, ReLU, pooling) project the data into a space where classes become linearly separable.

4. **Feature Compression**: The 28×28 = 784 input pixels are compressed to 128 features, yet classification performance remains excellent.

---

### ii. Why does this work at all? What role does the architecture play?

This phenomenon works due to several interrelated factors:

#### 1. **Architectural Inductive Bias**
The CNN architecture itself encodes strong priors about image structure:
- **Convolutional layers** enforce local connectivity and translation equivariance
- **Weight sharing** across spatial locations makes features invariant to position
- **Pooling layers** introduce local translation invariance and reduce dimensionality
- **Hierarchical structure** builds increasingly abstract representations

These architectural constraints mean that even random weights produce features that respect the spatial structure of images.

#### 2. **Nonlinear Random Projections**
The combination of random weights + ReLU activations creates a nonlinear random projection of the input. This is similar to how random projections in the Johnson-Lindenstrauss lemma preserve distances. The key insight is:
- Random linear projections preserve geometric structure
- Adding nonlinearities (ReLU) can make data more separable by "unfolding" the manifold

#### 3. **High-Dimensional Expansion**
The convolutional layers expand the representation:
- Input: 1 × 28 × 28 = 784 dimensions
- After Conv1: 16 × 28 × 28 = 12,544 dimensions
- After Pool1: 16 × 14 × 14 = 3,136 dimensions
- After Conv2: 32 × 14 × 14 = 6,272 dimensions
- After Pool2: 32 × 7 × 7 = 1,568 dimensions

This expansion into higher-dimensional space makes classes more likely to be linearly separable (Cover's theorem).

#### 4. **MNIST is "Easy"**
MNIST digits are well-centered, normalized, and have clear structure. The dataset's simplicity means even random transformations that respect basic image properties can separate the classes.

---

### iii. What support can you find in the research literature? (hint: think kernels)

Several research areas provide theoretical and empirical support for this phenomenon:

#### 1. **Random Features and Kernel Methods (Rahimi & Recht, 2007)**
The seminal paper "Random Features for Large-Scale Kernel Machines" showed that random Fourier features can approximate kernel functions. Our untrained CNN can be viewed as computing random features that approximate a specific kernel defined by the network architecture.

**Key insight**: A random neural network computes a randomized feature map φ(x), and the SVM learns in this feature space. This is equivalent to using a kernel K(x, x') = ⟨φ(x), φ(x')⟩.

#### 2. **Extreme Learning Machines (Huang et al., 2006)**
ELMs use random hidden layer weights with only the output layer trained. This is exactly analogous to our setup:
- Random CNN = fixed random feature extractor
- Linear SVM = trained output layer

ELM theory shows that with sufficiently many random neurons, universal approximation is still achievable.

#### 3. **Neural Tangent Kernel (Jacot et al., 2018)**
The NTK theory shows that infinitely wide neural networks behave like kernel methods. The kernel is determined by the architecture, not the specific weight values. This explains why random networks (which sample from the NTK distribution) can still perform well—they're implicitly computing features in a kernel space defined by the architecture.

#### 4. **Reservoir Computing & Echo State Networks (Jaeger, 2001; Maass et al., 2002)**
In reservoir computing, a fixed random "reservoir" of recurrent connections projects inputs into a high-dimensional space, and only a linear readout is trained. This paradigm is directly analogous to our experiment and has been successful in time-series prediction and speech recognition.

#### 5. **Convolutional Kernel Networks (Mairal et al., 2014)**
This work explicitly bridges CNNs and kernel methods, showing that CNN architectures define implicit kernels. Random convolutional features inherit the beneficial properties of these kernels.

#### 6. **"What is being transferred in transfer learning?" (Neyshabur et al., 2020)**
Research on transfer learning has shown that even random initializations in lower layers, when combined with trained upper layers, can perform surprisingly well. This suggests that architectural inductive biases contribute more than learned features for some tasks.

#### 7. **"Deep Image Prior" (Ulyanov et al., 2018)**
This paper demonstrated that untrained CNNs can be used for image restoration tasks (denoising, inpainting) purely based on their architectural prior. The structure of the network itself captures low-level image statistics.

---

## Summary

The success of random CNN features demonstrates that:

1. **Architecture matters more than weights for simple tasks** - The convolutional structure, pooling, and nonlinearities create a feature space where data becomes linearly separable.

2. **CNNs implement implicit kernels** - Random features from CNNs approximate kernel methods, with the kernel defined by the architecture.

3. **This connects deep learning to classical ML** - The relationship between random neural networks, kernel methods, and reservoir computing provides a unified theoretical framework.

---

## References

- Rahimi, A., & Recht, B. (2007). Random Features for Large-Scale Kernel Machines. *NeurIPS*.
- Huang, G. B., et al. (2006). Extreme Learning Machine: Theory and Applications. *Neurocomputing*.
- Jacot, A., et al. (2018). Neural Tangent Kernel: Convergence and Generalization in Neural Networks. *NeurIPS*.
- Mairal, J., et al. (2014). Convolutional Kernel Networks. *NeurIPS*.
- Ulyanov, D., et al. (2018). Deep Image Prior. *CVPR*.
- Neyshabur, B., et al. (2020). What is being transferred in transfer learning? *NeurIPS*.
