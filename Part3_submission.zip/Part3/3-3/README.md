# Byte Pair Encoding (BPE) Tokenizer - From Scratch

A pure Python implementation of the Byte Pair Encoding (BPE) algorithm for subword tokenization, with no external dependencies.

## Algorithm Overview

BPE builds a vocabulary of subword units through iterative merging:

1. **Initialize**: Start with all unique characters as the base vocabulary
2. **Count Pairs**: Find frequency of all adjacent token pairs
3. **Merge**: Combine the most frequent pair into a new token
4. **Update**: Replace all occurrences of that pair with the new token
5. **Repeat**: Continue for k iterations (e.g., 1000 merges)

## Files

- `bpe.py` - Core BPE implementation (pure Python, no dependencies)
- `train_bpe.py` - Training script for Shakespeare corpus
- `test_bpe.py` - Testing and demonstration script
- `download_data.sh` - Script to download Shakespeare corpus
- `README.md` - This file

## Requirements

**None!** This implementation uses only Python standard library.

Python 3.6+ recommended.

## Dataset

Download the Shakespeare corpus:

```bash
wget https://raw.githubusercontent.com/karpathy/char-rnn/master/data/tinyshakespeare/input.txt -O shakespeare.txt
```

Or run the provided script:

```bash
./download_data.sh
```

Or use any text file as your corpus.

## Usage

### Training

```bash
python train_bpe.py
```

This will:
- Load `shakespeare.txt`
- Train BPE with 1000 merge operations
- Display learned merge rules
- Save the model to `bpe_model.txt`
- Test encoding on "Alas, poor Yorick! I knew him, Horatio:"

**Output includes:**
- First 50 merge rules (common character combinations)
- Last 50 merge rules (complex subwords)
- Tokenization of the test string
- Compression statistics

### Testing

After training, run:

```bash
python test_bpe.py
```

This demonstrates:
- Tokenization of various Shakespeare quotes
- Analysis of merge rule patterns
- Compression ratios achieved

### Using as a Library

```python
from bpe import BytePairEncoding

# Train new tokenizer
bpe = BytePairEncoding()
bpe.train(your_text, num_merges=1000)

# Encode text
tokens = bpe.encode("Hello, world!")
print(tokens)  # List of subword tokens

# Save/load model
bpe.save('my_tokenizer.txt')

# Later…
new_bpe = BytePairEncoding()
new_bpe.load('my_tokenizer.txt')
```

## Expected Results

### Merge Rules

The algorithm learns rules progressing from simple to complex:

**Early merges** (frequent character pairs):
```
1. ('t', 'h') -> 'th'
2. ('e', ' ') -> 'e '
3. ('s', ' ') -> 's '
4. (' ', 't') -> ' t'
```

**Middle merges** (common words):
```
100. ('th', 'e ') -> 'the '
101. ('an', 'd ') -> 'and '
```

**Late merges** (rare/specific patterns):
```
980. ('First', ' Citizen') -> 'First Citizen'
981. ('Enter', ' ROMEO') -> 'Enter ROMEO'
```

### Test String Encoding

**Input**: `"Alas, poor Yorick! I knew him, Horatio:"`

**Output** (example - actual results depend on training):
```
A | la | s,  | po | or  | Y | or | ick | !  | I  | k | new |  him | ,  | H | or | at | io | :
```

**Compression**: 39 characters → 19 tokens (≈2.05x compression)

## How It Works

### Training Phase

```python
# 1. Start with characters
tokens = ['h', 'e', 'l', 'l', 'o']

# 2. Count pairs
pairs = {('l', 'l'): 1, ('e', 'l'): 1, ('l', 'o'): 1, ('h', 'e'): 1}

# 3. Most frequent pair (if 'll' occurs most in full corpus)
most_frequent = ('l', 'l')

# 4. Merge
tokens = ['h', 'e', 'll', 'o']

# 5. Repeat…
```

### Encoding Phase

Apply learned merge rules in the same order they were learned:

```python
text = "hello"
tokens = ['h', 'e', 'l', 'l', 'o']

# Apply rule 1: ('l', 'l') -> 'll'
tokens = ['h', 'e', 'll', 'o']

# Apply rule 2: ('e', 'll') -> 'ell'
tokens = ['h', 'ell', 'o']

# … continue with all rules
```

## Customization

Modify `train_bpe.py` to adjust:

```python
NUM_MERGES = 1000              # Vocabulary size control
CORPUS_FILE = 'your_text.txt'  # Different corpus
```

**Larger NUM_MERGES**:
- Larger vocabulary
- Fewer tokens per text (better compression)
- Longer subword units

**Smaller NUM_MERGES**:
- Smaller vocabulary
- More tokens per text
- Better handling of rare words

## Implementation Details

### Time Complexity

- **Training**: O(k × n) where k = num_merges, n = corpus size
  - Each iteration scans the corpus to count pairs and apply merges
  
- **Encoding**: O(m × L) where m = num_merges, L = input length
  - Apply each merge rule sequentially

### Space Complexity

- O(V + R) where V = vocab size, R = number of rules
- Corpus is stored as list of tokens

### Design Decisions

1. **Pure Python**: No external dependencies for maximum portability
2. **List-based**: Tokens stored as Python lists for simplicity
3. **Sequential merging**: Rules applied in order for correctness
4. **Readable code**: Clear variable names and comments

## Comparison to Production Tokenizers

This implementation prioritizes **clarity** over **performance**.

Production tokenizers (like GPT-2's BPE) use:
- Regex pre-tokenization to split on whitespace/punctuation
- Byte-level encoding for Unicode handling
- Efficient data structures (hash tables, tries)
- Parallel processing

Our implementation demonstrates the core algorithm and is suitable for:
- Educational purposes
- Understanding BPE internals
- Small to medium corpora
- Prototyping

## References

- Sennrich et al. (2016): "Neural Machine Translation of Rare Words with Subword Units"
- GPT-2 BPE implementation
- Hugging Face tokenizers library

## License

Educational use - free to modify and distribute.
