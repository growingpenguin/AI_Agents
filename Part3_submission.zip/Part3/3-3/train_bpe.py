"""
Training script for BPE tokenizer on Shakespeare corpus.

Deliverables:
(a) Show the final merge rules learned
(b) Show how the tokenizer encodes: "Alas, poor Yorick! I knew him, Horatio:"
(c) Full code packaged to run from scratch
"""

from bpe import BytePairEncoding


def main():
    # Configuration
    CORPUS_FILE = 'shakespeare.txt'
    NUM_MERGES = 1000
    MODEL_SAVE_PATH = 'bpe_model.txt'
    MERGE_RULES_FILE = 'merge_rules.txt'

    # Load corpus
    print("=" * 70)
    print("BYTE PAIR ENCODING (BPE) TOKENIZER TRAINING")
    print("=" * 70)
    print("\nLoading corpus...")
    with open(CORPUS_FILE, 'r', encoding='utf-8') as f:
        text = f.read()

    print(f"Corpus: {CORPUS_FILE}")
    print(f"Corpus length: {len(text):,} characters")
    print(f"Unique characters (initial vocabulary): {len(set(text))}")

    # Initialize and train BPE
    bpe = BytePairEncoding()
    bpe.train(text, num_merges=NUM_MERGES, verbose=True)

    # =========================================================================
    # DELIVERABLE (a): Show the final merge rules learned
    # =========================================================================
    print("\n" + "=" * 70)
    print("DELIVERABLE (a): MERGE RULES LEARNED")
    print("=" * 70)

    # Display first 50 merge rules
    print("\n--- FIRST 50 MERGE RULES (most frequent pairs) ---\n")
    for i, (pair, merged) in enumerate(bpe.merge_rules[:50], 1):
        # Format special characters for display
        p0 = repr(pair[0]) if pair[0] in ['\n', '\t', ' '] else f"'{pair[0]}'"
        p1 = repr(pair[1]) if pair[1] in ['\n', '\t', ' '] else f"'{pair[1]}'"
        m = repr(merged) if any(c in merged for c in ['\n', '\t']) else f"'{merged}'"
        print(f"  {i:4d}. ({p0}, {p1}) -> {m}")

    # Display last 50 merge rules
    print("\n--- LAST 50 MERGE RULES (less frequent, complex patterns) ---\n")
    for i, (pair, merged) in enumerate(bpe.merge_rules[-50:], NUM_MERGES - 49):
        p0 = repr(pair[0]) if pair[0] in ['\n', '\t', ' '] else f"'{pair[0]}'"
        p1 = repr(pair[1]) if pair[1] in ['\n', '\t', ' '] else f"'{pair[1]}'"
        m = repr(merged) if any(c in merged for c in ['\n', '\t']) else f"'{merged}'"
        print(f"  {i:4d}. ({p0}, {p1}) -> {m}")

    # Save ALL merge rules to a separate file
    print(f"\n[All {NUM_MERGES} merge rules saved to '{MERGE_RULES_FILE}']")
    with open(MERGE_RULES_FILE, 'w', encoding='utf-8') as f:
        f.write(f"BPE MERGE RULES - {NUM_MERGES} total merges\n")
        f.write(f"Trained on: {CORPUS_FILE} ({len(text):,} characters)\n")
        f.write("=" * 60 + "\n\n")
        for i, (pair, merged) in enumerate(bpe.merge_rules, 1):
            p0 = repr(pair[0])
            p1 = repr(pair[1])
            m = repr(merged)
            f.write(f"{i:4d}. ({p0}, {p1}) -> {m}\n")

    # =========================================================================
    # DELIVERABLE (b): Show encoding of test string
    # =========================================================================
    test_string = "Alas, poor Yorick! I knew him, Horatio:"

    print("\n" + "=" * 70)
    print("DELIVERABLE (b): ENCODING TEST STRING")
    print("=" * 70)
    print(f'\nInput string: "{test_string}"')
    print(f"String length: {len(test_string)} characters\n")

    tokens = bpe.encode(test_string)

    print("Encoded tokens (separated by |):")
    print(bpe.encode_to_string(test_string))

    print("\nToken-by-token breakdown:")
    print("-" * 40)
    for i, token in enumerate(tokens, 1):
        # Display representation for whitespace characters
        if token == ' ':
            token_display = "' ' (space)"
        elif token == '\n':
            token_display = "'\\n' (newline)"
        elif token == '\t':
            token_display = "'\\t' (tab)"
        elif ' ' in token:
            token_display = repr(token)
        else:
            token_display = f"'{token}'"
        print(f"  Token {i:2d}: {token_display}")

    print("-" * 40)
    print(f"\nSummary:")
    print(f"  - Original characters: {len(test_string)}")
    print(f"  - Encoded tokens: {len(tokens)}")
    print(f"  - Compression ratio: {len(test_string) / len(tokens):.2f}x")

    # =========================================================================
    # Save model
    # =========================================================================
    print("\n" + "=" * 70)
    print("MODEL SAVED")
    print("=" * 70)
    bpe.save(MODEL_SAVE_PATH)
    print(f"\nModel saved to: {MODEL_SAVE_PATH}")
    print(f"Vocabulary size: {len(bpe.vocab)}")
    print(f"Merge rules: {len(bpe.merge_rules)}")

    print("\n" + "=" * 70)
    print("TRAINING COMPLETE")
    print("=" * 70)
    print("\nTo test the trained model, run:")
    print("  python test_bpe.py")


if __name__ == '__main__':
    main()
