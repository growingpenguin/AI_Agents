"""
Byte Pair Encoding (BPE) Tokenizer - From Scratch Implementation
No external dependencies required (pure Python)
"""

from collections import Counter
from typing import List, Tuple, Dict


class BytePairEncoding:
    """
    Byte Pair Encoding tokenizer implementation from scratch.

    BPE iteratively merges the most frequent adjacent pairs of tokens
    to build a subword vocabulary.
    """

    def __init__(self):
        self.vocab = set()  # Set of all tokens
        self.merge_rules = []  # List of (pair, merged_token) in order
        self.merge_dict = {}  # Dictionary for fast lookup: (a, b) -> merged_token

    def get_stats(self, tokens: List[str]) -> Counter:
        """
        Count frequency of all adjacent pairs in the token sequence.

        Args:
            tokens: List of tokens (initially characters, later subwords)

        Returns:
            Counter object with pair frequencies
        """
        pairs = Counter()
        for i in range(len(tokens) - 1):
            pair = (tokens[i], tokens[i + 1])
            pairs[pair] += 1
        return pairs

    def merge_pair(self, tokens: List[str], pair: Tuple[str, str], new_token: str) -> List[str]:
        """
        Replace all occurrences of a pair with the merged token.

        Args:
            tokens: Current token sequence
            pair: Tuple of (token1, token2) to merge
            new_token: The merged result

        Returns:
            New token sequence with pairs merged
        """
        new_tokens = []
        i = 0

        while i < len(tokens):
            # Check if current position forms the target pair
            if i < len(tokens) - 1 and (tokens[i], tokens[i + 1]) == pair:
                new_tokens.append(new_token)
                i += 2  # Skip both tokens in the pair
            else:
                new_tokens.append(tokens[i])
                i += 1

        return new_tokens

    def train(self, text: str, num_merges: int = 1000, verbose: bool = True):
        """
        Train BPE tokenizer on a text corpus.

        Args:
            text: Training text corpus
            num_merges: Number of merge operations (vocabulary expansion)
            verbose: Whether to print progress
        """
        # Initialize vocabulary with all unique characters
        self.vocab = set(text)

        # Initialize token sequence as list of characters
        tokens = list(text)

        if verbose:
            print(f"Initial vocabulary size: {len(self.vocab)}")
            print(f"Initial token count: {len(tokens)}")
            print(f"\nStarting BPE training with {num_merges} merges...\n")

        # Perform merge iterations
        for iteration in range(num_merges):
            # Count all adjacent pairs
            pair_freqs = self.get_stats(tokens)

            if not pair_freqs:
                if verbose:
                    print(f"No more pairs to merge at iteration {iteration}")
                break

            # Find most frequent pair
            most_frequent_pair = max(pair_freqs.items(), key=lambda x: x[1])
            pair, freq = most_frequent_pair

            # Create new merged token
            new_token = pair[0] + pair[1]

            # Store merge rule
            self.merge_rules.append((pair, new_token))
            self.merge_dict[pair] = new_token

            # Add to vocabulary
            self.vocab.add(new_token)

            # Apply merge to entire corpus
            tokens = self.merge_pair(tokens, pair, new_token)

            # Progress update
            if verbose and (iteration + 1) % 100 == 0:
                print(f"Iteration {iteration + 1}/{num_merges}: "
                      f"Merged {pair} -> '{new_token}' (freq: {freq}), "
                      f"Token count: {len(tokens)}")

        if verbose:
            print(f"\nTraining complete!")
            print(f"Final vocabulary size: {len(self.vocab)}")
            print(f"Final token count: {len(tokens)}")
            print(f"Total merge rules learned: {len(self.merge_rules)}")

    def encode(self, text: str) -> List[str]:
        """
        Encode text using learned BPE merge rules.

        Args:
            text: Text to encode

        Returns:
            List of subword tokens
        """
        # Start with character-level tokens
        tokens = list(text)

        # Apply merge rules in order
        for pair, new_token in self.merge_rules:
            tokens = self.merge_pair(tokens, pair, new_token)

        return tokens

    def encode_to_string(self, text: str) -> str:
        """
        Encode text and return as a readable string.

        Args:
            text: Text to encode

        Returns:
            Space-separated token string
        """
        tokens = self.encode(text)
        return ' | '.join(tokens)

    def get_merge_rules_summary(self, num_rules: int = None) -> str:
        """
        Get a formatted summary of learned merge rules.

        Args:
            num_rules: Number of rules to display (None = all)

        Returns:
            Formatted string of merge rules
        """
        rules_to_show = self.merge_rules[:num_rules] if num_rules else self.merge_rules

        summary = f"Learned {len(self.merge_rules)} merge rules\n"
        summary += "=" * 60 + "\n"

        for i, (pair, merged) in enumerate(rules_to_show, 1):
            # Visualize special characters
            token1 = repr(pair[0]) if pair[0] in ['\n', '\t', ' '] else pair[0]
            token2 = repr(pair[1]) if pair[1] in ['\n', '\t', ' '] else pair[1]
            merged_repr = repr(merged) if any(c in merged for c in ['\n', '\t']) else merged

            summary += f"{i:4d}. ({token1}, {token2}) -> {merged_repr}\n"

        if num_rules and len(self.merge_rules) > num_rules:
            summary += f"\n... and {len(self.merge_rules) - num_rules} more rules\n"

        return summary

    def save(self, filepath: str):
        """
        Save trained BPE model to file.

        Args:
            filepath: Path to save file
        """
        with open(filepath, 'w', encoding='utf-8') as f:
            # Save vocabulary
            f.write("VOCAB\n")
            for token in sorted(self.vocab):
                f.write(repr(token) + '\n')

            # Save merge rules
            f.write("\nMERGE_RULES\n")
            for (token1, token2), merged in self.merge_rules:
                f.write(f"{repr(token1)}\t{repr(token2)}\t{repr(merged)}\n")

    def load(self, filepath: str):
        """
        Load trained BPE model from file.

        Args:
            filepath: Path to model file
        """
        with open(filepath, 'r', encoding='utf-8') as f:
            lines = f.readlines()

        mode = None
        self.vocab = set()
        self.merge_rules = []
        self.merge_dict = {}

        for line in lines:
            line = line.strip()

            if line == "VOCAB":
                mode = "vocab"
                continue
            elif line == "MERGE_RULES":
                mode = "rules"
                continue

            if not line:
                continue

            if mode == "vocab":
                token = eval(line)
                self.vocab.add(token)
            elif mode == "rules":
                parts = line.split('\t')
                token1 = eval(parts[0])
                token2 = eval(parts[1])
                merged = eval(parts[2])

                pair = (token1, token2)
                self.merge_rules.append((pair, merged))
                self.merge_dict[pair] = merged
