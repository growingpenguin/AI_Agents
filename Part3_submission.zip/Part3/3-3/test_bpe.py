"""
Demonstration and testing script for trained BPE tokenizer.
"""

from bpe import BytePairEncoding


def test_tokenizer():
    """Test the trained BPE tokenizer on various inputs."""

    # Load trained model
    print("Loading trained BPE model...")
    bpe = BytePairEncoding()
    bpe.load('bpe_model.txt')

    print(f"Loaded model with {len(bpe.merge_rules)} merge rules")
    print(f"Vocabulary size: {len(bpe.vocab)}\n")

    # Test strings
    test_strings = [
        "Alas, poor Yorick! I knew him, Horatio:",
        "To be, or not to be, that is the question:",
        "Romeo, Romeo, wherefore art thou Romeo?",
        "The course of true love never did run smooth.",
        "All the world's a stage,",
    ]

    print("=" * 70)
    print("TOKENIZATION EXAMPLES")
    print("=" * 70)

    for test_str in test_strings:
        print(f"\nInput: \"{test_str}\"")
        print("-" * 70)

        tokens = bpe.encode(test_str)
        print(f"Tokens ({len(tokens)}): {bpe.encode_to_string(test_str)}")
        print(f"Compression: {len(test_str)} chars -> {len(tokens)} tokens "
              f"({len(test_str) / len(tokens):.2f}x)")


def analyze_merge_rules():
    """Analyze the learned merge rules."""

    bpe = BytePairEncoding()
    bpe.load('bpe_model.txt')

    print("\n" + "=" * 70)
    print("MERGE RULES ANALYSIS")
    print("=" * 70)

    # Show different stages of merges
    print("\n--- First 20 merges (character combinations) ---")
    print(bpe.get_merge_rules_summary(num_rules=20))

    print("\n--- Merges 100-120 (common subwords) ---")
    middle_bpe = BytePairEncoding()
    middle_bpe.merge_rules = bpe.merge_rules[99:120]
    print(middle_bpe.get_merge_rules_summary())

    print("\n--- Last 20 merges (rare/long subwords) ---")
    last_bpe = BytePairEncoding()
    last_bpe.merge_rules = bpe.merge_rules[-20:]
    print(last_bpe.get_merge_rules_summary())

    # Find interesting patterns
    print("\n--- Interesting patterns ---")
    common_words = []
    space_patterns = []

    for pair, merged in bpe.merge_rules[:500]:
        if len(merged) >= 4 and ' ' not in merged:
            common_words.append(merged)
        if ' ' in pair[0] or ' ' in pair[1]:
            space_patterns.append((pair, merged))

    print(f"\nLong tokens learned (>= 4 chars, first 20):")
    for word in common_words[:20]:
        print(f"  - '{word}'")

    print(f"\nWord boundary patterns (first 10):")
    for pair, merged in space_patterns[:10]:
        p0 = repr(pair[0]) if pair[0] == ' ' else pair[0]
        p1 = repr(pair[1]) if pair[1] == ' ' else pair[1]
        m = repr(merged) if ' ' in merged else merged
        print(f"  ({p0}, {p1}) -> {m}")


if __name__ == '__main__':
    test_tokenizer()
    analyze_merge_rules()
