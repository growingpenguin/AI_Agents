"""
Training script for character-level Transformer on Shakespeare dataset.
"""

import torch
import torch.nn as nn
from torch.optim import Adam
from tqdm import tqdm
import random
import numpy as np

from model import CharTransformer
from data_utils import get_dataloaders

# Set random seeds for reproducibility
SEED = 42
random.seed(SEED)
np.random.seed(SEED)
torch.manual_seed(SEED)
if torch.cuda.is_available():
    torch.cuda.manual_seed(SEED)
    torch.backends.cudnn.deterministic = True


def train_epoch(model, train_loader, optimizer, criterion, device):
    """Train for one epoch"""
    model.train()
    total_loss = 0

    pbar = tqdm(train_loader, desc='Training')
    for x, y in pbar:
        x, y = x.to(device), y.to(device)

        # Forward pass
        logits = model(x)  # (batch_size, seq_len, vocab_size)

        # Reshape for cross entropy: (batch_size * seq_len, vocab_size)
        logits = logits.view(-1, logits.size(-1))
        y = y.view(-1)

        # Compute loss
        loss = criterion(logits, y)

        # Backward pass
        optimizer.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
        optimizer.step()

        total_loss += loss.item()
        pbar.set_postfix({'loss': loss.item()})

    return total_loss / len(train_loader)


@torch.no_grad()
def evaluate(model, val_loader, criterion, device):
    """Evaluate on validation set"""
    model.eval()
    total_loss = 0

    for x, y in val_loader:
        x, y = x.to(device), y.to(device)

        logits = model(x)
        logits = logits.view(-1, logits.size(-1))
        y = y.view(-1)

        loss = criterion(logits, y)
        total_loss += loss.item()

    return total_loss / len(val_loader)


def main():
    # Hyperparameters (sized for quick training on laptop)
    BLOCK_SIZE = 64  # Context window
    BATCH_SIZE = 128  # Batch size
    D_MODEL = 128  # Model dimension
    NUM_HEADS = 4  # Number of attention heads
    NUM_LAYERS = 3  # Number of transformer blocks
    D_FF = 512  # Feed-forward dimension
    DROPOUT = 0.1  # Dropout rate
    LEARNING_RATE = 3e-4
    NUM_EPOCHS = 10

    # Device selection: CUDA > MPS (Apple Silicon) > CPU
    if torch.cuda.is_available():
        device = torch.device('cuda')
    elif torch.backends.mps.is_available():
        device = torch.device('mps')
    else:
        device = torch.device('cpu')
    print(f"Using device: {device}")

    # Load data
    print("Loading dataset...")
    train_loader, val_loader, dataset = get_dataloaders(
        'shakespeare.txt',
        block_size=BLOCK_SIZE,
        batch_size=BATCH_SIZE
    )

    vocab_size = dataset.vocab_size
    print(f"Vocabulary size: {vocab_size}")
    print(f"Training samples: {len(dataset)}")

    # Initialize model
    model = CharTransformer(
        vocab_size=vocab_size,
        d_model=D_MODEL,
        num_heads=NUM_HEADS,
        num_layers=NUM_LAYERS,
        d_ff=D_FF,
        max_len=BLOCK_SIZE,
        dropout=DROPOUT
    ).to(device)

    print(f"\nModel parameters: {sum(p.numel() for p in model.parameters()):,}")

    # Training setup
    criterion = nn.CrossEntropyLoss()
    optimizer = Adam(model.parameters(), lr=LEARNING_RATE)

    # Training loop
    best_val_loss = float('inf')

    print("\nStarting training...")
    for epoch in range(NUM_EPOCHS):
        print(f"\nEpoch {epoch + 1}/{NUM_EPOCHS}")

        train_loss = train_epoch(model, train_loader, optimizer, criterion, device)
        val_loss = evaluate(model, val_loader, criterion, device)

        print(f"Train Loss: {train_loss:.4f} | Val Loss: {val_loss:.4f}")

        # Save best model
        if val_loss < best_val_loss:
            best_val_loss = val_loss
            torch.save({
                'epoch': epoch,
                'model_state_dict': model.state_dict(),
                'optimizer_state_dict': optimizer.state_dict(),
                'train_loss': train_loss,
                'val_loss': val_loss,
                'char_to_idx': dataset.char_to_idx,
                'idx_to_char': dataset.idx_to_char,
                'vocab_size': vocab_size,
                'model_config': {
                    'd_model': D_MODEL,
                    'num_heads': NUM_HEADS,
                    'num_layers': NUM_LAYERS,
                    'd_ff': D_FF,
                    'max_len': BLOCK_SIZE,
                    'dropout': DROPOUT
                }
            }, 'best_model.pt')
            print(f"Model saved! (Val Loss: {val_loss:.4f})")

    print(f"\nTraining complete! Best validation loss: {best_val_loss:.4f}")


if __name__ == '__main__':
    main()
