"""
Text generation script using trained Transformer model.
"""

import torch
import torch.nn.functional as F
from model import CharTransformer


def generate_text(model, prompt, dataset, max_new_tokens=500, temperature=0.8, device='cpu'):
    """
    Generate text from a prompt using the trained model.

    Args:
        model: Trained CharTransformer model
        prompt: Initial text prompt
        dataset: Dataset object with char_to_idx and idx_to_char mappings
        max_new_tokens: Number of characters to generate
        temperature: Sampling temperature (higher = more random)
        device: Device to run on

    Returns:
        Generated text string
    """
    model.eval()

    # Encode prompt
    context = torch.tensor([dataset.encode(prompt)], dtype=torch.long).to(device)

    generated = prompt

    with torch.no_grad():
        for _ in range(max_new_tokens):
            # Get predictions for the last position
            logits = model(context)  # (1, seq_len, vocab_size)
            logits = logits[:, -1, :] / temperature  # (1, vocab_size)

            # Sample from distribution
            probs = F.softmax(logits, dim=-1)
            next_char_idx = torch.multinomial(probs, num_samples=1)

            # Append to context
            context = torch.cat([context, next_char_idx], dim=1)

            # Decode and append to generated text
            next_char = dataset.idx_to_char[next_char_idx.item()]
            generated += next_char

            # Limit context window to max_len used during training
            if context.size(1) > 64:
                context = context[:, -64:]

    return generated


def main():
    # Device selection: CUDA > MPS (Apple Silicon) > CPU
    if torch.cuda.is_available():
        device = torch.device('cuda')
    elif torch.backends.mps.is_available():
        device = torch.device('mps')
    else:
        device = torch.device('cpu')
    print(f"Using device: {device}")

    # Load checkpoint
    print("Loading model...")
    checkpoint = torch.load('best_model.pt', map_location=device)

    # Recreate model
    config = checkpoint['model_config']
    model = CharTransformer(
        vocab_size=checkpoint['vocab_size'],
        d_model=config['d_model'],
        num_heads=config['num_heads'],
        num_layers=config['num_layers'],
        d_ff=config['d_ff'],
        max_len=config['max_len'],
        dropout=0.0  # No dropout during inference
    ).to(device)

    model.load_state_dict(checkpoint['model_state_dict'])

    # Create a simple dataset wrapper for encoding/decoding
    class VocabWrapper:
        def __init__(self, char_to_idx, idx_to_char):
            self.char_to_idx = char_to_idx
            self.idx_to_char = idx_to_char

        def encode(self, text):
            return [self.char_to_idx[ch] for ch in text]

    vocab = VocabWrapper(checkpoint['char_to_idx'], checkpoint['idx_to_char'])

    print("Model loaded successfully!\n")

    # Generate text with different prompts
    prompts = [
        "JULIET:",
        "ROMEO:",
        "First Citizen:",
        "KING:",
        "Lord:"
    ]

    print("=" * 70)
    print("GENERATED TEXT SAMPLES")
    print("=" * 70)

    for prompt in prompts:
        print(f"\nPrompt: '{prompt}'")
        print("-" * 70)

        generated = generate_text(
            model=model,
            prompt=prompt,
            dataset=vocab,
            max_new_tokens=400,
            temperature=0.8,
            device=device
        )

        # Print generated text (limit lines for readability)
        lines = generated.split('\n')
        for line in lines[:15]:  # Show first 15 lines
            print(line)
        print()


if __name__ == '__main__':
    main()
