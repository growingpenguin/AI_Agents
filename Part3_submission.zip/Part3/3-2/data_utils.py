"""
Data utilities for loading and preprocessing text data.
"""

import torch
from torch.utils.data import Dataset, DataLoader


class CharDataset(Dataset):
    """Character-level dataset for text generation."""

    def __init__(self, text, block_size, char_to_idx=None, idx_to_char=None):
        """
        Args:
            text: Input text string
            block_size: Length of context window (sequence length)
            char_to_idx: Optional pre-built character to index mapping
            idx_to_char: Optional pre-built index to character mapping
        """
        if char_to_idx is None or idx_to_char is None:
            # Build vocabulary from text if not provided
            chars = sorted(list(set(text)))
            self.char_to_idx = {ch: i for i, ch in enumerate(chars)}
            self.idx_to_char = {i: ch for i, ch in enumerate(chars)}
        else:
            # Use provided vocabulary
            self.char_to_idx = char_to_idx
            self.idx_to_char = idx_to_char

        self.vocab_size = len(self.char_to_idx)

        # Encode entire text
        self.data = [self.char_to_idx[ch] for ch in text]
        self.block_size = block_size

    def __len__(self):
        return len(self.data) - self.block_size

    def __getitem__(self, idx):
        """
        Returns:
            x: Input sequence of length block_size
            y: Target sequence (shifted by 1)
        """
        chunk = self.data[idx:idx + self.block_size + 1]
        x = torch.tensor(chunk[:-1], dtype=torch.long)
        y = torch.tensor(chunk[1:], dtype=torch.long)
        return x, y

    def decode(self, indices):
        """Convert indices back to text"""
        return ''.join([self.idx_to_char[i] for i in indices])

    def encode(self, text):
        """Convert text to indices"""
        return [self.char_to_idx[ch] for ch in text]


def get_dataloaders(text_file, block_size=128, batch_size=64, train_split=0.9):
    """
    Load text file and create train/val dataloaders.

    Args:
        text_file: Path to text file
        block_size: Context window size
        batch_size: Batch size for training
        train_split: Fraction of data to use for training

    Returns:
        train_loader, val_loader, dataset
    """
    # Read text file
    with open(text_file, 'r', encoding='utf-8') as f:
        text = f.read()

    # Build vocabulary from ENTIRE text to ensure all characters are covered
    chars = sorted(list(set(text)))
    char_to_idx = {ch: i for i, ch in enumerate(chars)}
    idx_to_char = {i: ch for i, ch in enumerate(chars)}

    # Split into train and validation
    split_idx = int(len(text) * train_split)
    train_text = text[:split_idx]
    val_text = text[split_idx:]

    # Create datasets with shared vocabulary
    train_dataset = CharDataset(train_text, block_size, char_to_idx, idx_to_char)
    val_dataset = CharDataset(val_text, block_size, char_to_idx, idx_to_char)

    # Create dataloaders
    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True, num_workers=0)
    val_loader = DataLoader(val_dataset, batch_size=batch_size, shuffle=False, num_workers=0)

    return train_loader, val_loader, train_dataset
