#!/bin/bash
# Download Shakespeare dataset

echo "Downloading Tiny Shakespeare dataset..."
wget https://raw.githubusercontent.com/karpathy/char-rnn/master/data/tinyshakespeare/input.txt -O shakespeare.txt

if [ -f shakespeare.txt ]; then
    echo "Download complete! File saved as shakespeare.txt"
    wc -l shakespeare.txt
else
    echo "Download failed. Please download manually from:"
    echo "https://raw.githubusercontent.com/karpathy/char-rnn/master/data/tinyshakespeare/input.txt"
fi
