# Decoder-Only Transformer for Character-Level Text Generation

A from-scratch implementation of a decoder-only Transformer for character-level language modeling on Shakespeare's works.

## Features

- **Custom Multi-Head Attention**: Implements scaled dot-product attention with causal masking
- **Transformer Blocks**: Pre-LN architecture with residual connections
- **Sinusoidal Positional Encoding**: Original "Attention is All You Need" style
- **No High-Level Modules**: Built only with PyTorch primitives (nn.Linear, nn.LayerNorm, nn.Embedding, torch.matmul, etc.)

## Dataset

Download the Tiny Shakespeare dataset:

```bash
wget https://raw.githubusercontent.com/karpathy/char-rnn/master/data/tinyshakespeare/input.txt -O shakespeare.txt
```

Or run the provided script:

```bash
bash download_data.sh
```

## Installation

Create virtual environment:

```bash
python3 -m venv venv
source venv/bin/activate  # On macOS/Linux
# or
venv\Scripts\activate  # On Windows
```

Install dependencies:

```bash
pip install -r requirements.txt
```

## Usage

### Training

```bash
python train.py
```

Training parameters (modify in `train.py`):
- `BLOCK_SIZE`: 64 (context window)
- `BATCH_SIZE`: 128
- `D_MODEL`: 128 (model dimension)
- `NUM_HEADS`: 4 (attention heads)
- `NUM_LAYERS`: 3 (transformer blocks)
- `NUM_EPOCHS`: 10

Expected training time: ~5-10 minutes on GPU/MPS, ~20-40 minutes on CPU

### Generation

After training completes:

```bash
python generate.py
```

This will generate text samples from multiple prompts (JULIET:, ROMEO:, etc.) and display 10-15 lines per prompt.

## Model Architecture

```
Input (character indices)
        ↓
Character Embedding × √d_model
        ↓
Positional Encoding (sinusoidal)
        ↓
┌─────────────────────────────┐
│   Transformer Block × 3     │
│  ┌────────────────────────┐ │
│  │ LayerNorm              │ │
│  │ Multi-Head Attention   │ │
│  │   (causal masked)      │ │
│  │ + Residual Connection  │ │
│  ├────────────────────────┤ │
│  │ LayerNorm              │ │
│  │ FFN (Linear→ReLU→Linear)│ │
│  │ + Residual Connection  │ │
│  └────────────────────────┘ │
└─────────────────────────────┘
        ↓
Final LayerNorm
        ↓
Linear → Vocabulary Logits
```

### MultiHeadAttention Implementation

The attention mechanism follows the formula:

**Attention(Q, K, V) = softmax(QK^T / √d_k) V**

- Q, K, V projections via `nn.Linear`
- Split into multiple heads
- Causal mask applied for autoregressive decoding
- Heads concatenated and passed through output projection

### TransformerBlock (Pre-LN)

```
x → LayerNorm → MultiHeadAttention → + → LayerNorm → FFN → + → output
    └──────────────────────────────↗     └─────────────────↗
           (residual)                        (residual)
```

## Reproducibility

Fixed random seeds are set in `train.py`:
- Python random: 42
- NumPy: 42
- PyTorch: 42
- CUDA (if available): 42

## Expected Results

After training for 10 epochs, the model generates Shakespeare-style text with:
- Proper character names and dialogue format
- Grammatical structure
- Vocabulary matching the corpus

Sample quality improves with more epochs and larger model configurations.

## Files

- `model.py` - Transformer architecture (MultiHeadAttention, TransformerBlock, CharTransformer)
- `train.py` - Training script with hyperparameters
- `generate.py` - Text generation from prompts
- `data_utils.py` - Dataset loading and preprocessing
- `requirements.txt` - Python dependencies
- `download_data.sh` - Script to download Shakespeare dataset

## References

- "Attention is All You Need" (Vaswani et al., 2017)
- "Language Models are Unsupervised Multitask Learners" (GPT-2)
- Karpathy's nanoGPT and char-rnn projects
